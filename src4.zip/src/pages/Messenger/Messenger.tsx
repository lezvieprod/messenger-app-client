
import { Box, Flex, Heading } from '@chakra-ui/layout';
import React from 'react';
import DialogsContainer from '../../containers/Dialogs/DialogsContainer';

export const Messenger: React.FC = () => {
  return (
    <Flex bg={'brand.700'} h={'100%'} borderRadius={'md'}>
      <Flex flexDirection={'column'} minW={'380px'}>
        <Box p={5}>
          <Heading fontSize={'22px'} color={'purple.400'}>Security Messenger</Heading>
        </Box>
        <DialogsContainer />
      </Flex>
      <Box w={'100%'}>
        <Flex flexDirection={'column'} w={'100%'} h={'100%'} pr={5}>
          <Flex alignItems={'center'} w={'100%'} h={'60px'} px={5}>
            dialog title
          </Flex>
          <Box w={'100%'} p={5} bg={'brand.900'} h={'100%'} borderRadius={'md'}>
            mess
          </Box>
          <Flex alignItems={'center'} w={'100%'} h={'60px'} px={5}>
            enter
          </Flex>
        </Flex>
      </Box>
    </Flex>
  );
}

export default Messenger;

import React from 'react';
import { useMutateWithAlert } from '../../hooks/mutate.hook';
import { useQueryWithErrorHandling } from '../../hooks/query.hook';
import { UsersList } from '../../pages/UsersList/UsersList';
import { useCreateDialogMutation, useGetAllUsersQuery } from '../../store/api';
import { IUser } from '../../types/models/User';

const UsersListContainer: React.FC = () => {

  const { data, error, isLoading, isFetching } = useQueryWithErrorHandling<IUser[]>(useGetAllUsersQuery)
  const { asyncMutate } = useMutateWithAlert()
  const [createDialog] = useCreateDialogMutation()

  const onCreateDialogHandle = async (user: IUser) => {
    await asyncMutate(createDialog(user))
  }

  return <UsersList
    {...data}
    isLoading={isLoading}
    isFetching={isFetching}
    error={error}
    onCreateDialogHandle={onCreateDialogHandle}
  />
}


export default UsersListContainer;

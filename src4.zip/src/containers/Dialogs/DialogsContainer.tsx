import React from 'react';
import { Dialogs } from '../../components/Dialogs/Dialogs';
import { useQueryWithErrorHandling } from '../../hooks/query.hook';
import { useGetAllDialogsQuery } from '../../store/api';
import { IDialog } from '../../types/models/Dialog';

const DialogsContainer = () => {

  const { data, error, isLoading, isFetching } = useQueryWithErrorHandling<IDialog[]>(useGetAllDialogsQuery)

  return <Dialogs {...data} isLoading={isLoading} isFetching={isFetching} error={error} />
}

export default DialogsContainer;

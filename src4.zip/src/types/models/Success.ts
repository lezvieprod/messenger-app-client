export interface IResponseSuccess {
  title: string,
  message: string
}
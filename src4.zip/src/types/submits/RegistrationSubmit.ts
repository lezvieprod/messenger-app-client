export interface IRegSubmit {
  email: string,
  password: string,
  firstName: string,
  lastName: string,
}
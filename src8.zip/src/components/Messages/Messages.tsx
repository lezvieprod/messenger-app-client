import Icon from '@chakra-ui/icon';
import { Input } from '@chakra-ui/input';
import { Box, Flex } from '@chakra-ui/layout';
import React, { ChangeEvent, memo, useState } from 'react';
import { useAuth } from '../../hooks/auth.hook';
import { IMessage } from '../../types/models/Message';
import { IoSend } from "react-icons/io5";
import { Button } from '@chakra-ui/button';
import { useParams } from 'react-router';
import { IResponseError } from '../../types/models/Error';

interface IMessagesProps {
  onAddMessageHandle(message: IMessage): void
  onDeleteMessageHandle(_id: string): void,
  onWritingMessageHandle(isWriting: boolean): void
  // data?: IMessage[],
  messages?: IMessage[],
  // addMessageLoading: boolean,
  // total?: number,
  // isLoading: boolean,
  // isFetching: boolean,
  // error?: {
  //   data: IResponseError
  // }
}


export const Messages: React.FC<IMessagesProps> = ({
  onAddMessageHandle,
  onDeleteMessageHandle,
  onWritingMessageHandle,
  // data,
  // isLoading,
  // isFetching,
  // addMessageLoading,
  messages
}) => {

  // const isGlobalLoading = isLoading || isFetching

  const { dialogId } = useParams<Record<string, string>>()
  const [message, setMessage] = useState<string>('')
  const { firstName, lastName } = useAuth()

  const addMessage = () => {
    onAddMessageHandle({ message, author: firstName! + ' ' + lastName!, dialogId })
    setMessage('')
  }

  const onEnterMessage = (e: ChangeEvent<HTMLInputElement>) => {
    setMessage(e.target.value)
    onWritingMessageHandle(true)
  }

  return (
    <Flex flexDirection={'column'} w={'100%'} h={'100%'} pr={5} >
      <Flex alignItems={'center'} w={'100%'} h={'60px'} px={5}  >
        dialog title
      </Flex>
      <Box w={'100%'} p={5} bg={'brand.900'} h={'100%'} borderRadius={'md'}>
        <Flex flexDirection={'column'} h={'100%'}>
          <Flex flexDirection={'column'} mt={'auto'}>
            {messages && messages.map(message => <MessageItem key={message._id} message={message} onDeleteMessageHandle={onDeleteMessageHandle} />)}
          </Flex>
        
        </Flex>
      </Box>
      <Flex alignItems={'center'} w={'100%'} h={'60px'} px={5}>
        <Input
          variant="unstyled"
          focusBorderColor={'purple.400'}
          placeholder={'Напишите сообщение...'}
          value={message}
          onChange={onEnterMessage}

        />
        <Button
          ml={4}
          variant={'ghost'}
          colorScheme={'purple'}
          _focus={{ boxShadow: "none" }}
          onClick={addMessage}
        // isLoading={isGlobalLoading || addMessageLoading}
        >
          <Icon as={IoSend} boxSize={'25px'} color={'purple.400'} />
        </Button>
      </Flex>
    </Flex>
  );
}

const MessageItem: React.FC<{ message: IMessage, onDeleteMessageHandle(_id: string): void }> = memo(({
  message,
  onDeleteMessageHandle
}) => {

  return (
    <Flex justifyContent={'space-between'} alignItems={'center'} mt={4} data-message-id={message._id}>
      <Box>
        <Flex>от: <Box color={'purple.500'} ml={1}>{message.author}</Box> </Flex>
        {message.message}
      </Box>
      <Box>
        <Button size={'sm'} onClick={() => onDeleteMessageHandle(message._id!)}>Удалить</Button>
      </Box>
    </Flex>
  )
})



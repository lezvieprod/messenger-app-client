export interface IMessageSubmit {
  message: string,
  author: string,
  dialogId: string
}